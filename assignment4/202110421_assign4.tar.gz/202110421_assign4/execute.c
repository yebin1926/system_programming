/*--------------------------------------------------------------------*/
/* execute.c */
/* Author: Jongki Park, Kyoungsoo Park */
/*--------------------------------------------------------------------*/

#include "dynarray.h"
#include "token.h"
#include "util.h"
#include "lexsyn.h"
#include "snush.h"
#include "execute.h"
#include "job.h"

extern struct job_manager *manager;
extern volatile sig_atomic_t sigchld_flag;
extern volatile sig_atomic_t sigint_flag;

/*--------------------------------------------------------------------*/
void block_signal(int sig, int block) { //Temporarily block or unblock a specific signal (like SIGCHLD or SIGINT) for the current process
    //sig: which signal to affect (e.g. SIGCHLD).
    //block: if non-zero → block; if 0 → unblock.
    sigset_t set;           //a signal set object (a bitmask-like structure that can hold multiple signals). it holds signals we want to change
    sigemptyset(&set);      //Initializes set to be empty (no signals in it).
    sigaddset(&set, sig);   //Adds the signal sig to the set.

    if (sigprocmask(block ? SIG_BLOCK : SIG_UNBLOCK, &set, NULL) < 0) { //If block != 0 → use SIG_BLOCK (add these signals to the blocked set). Else, use SIG_UNBLOCK (remove these signals from the blocked set).
        fprintf(stderr, 
            "[Error] block_signal: sigprocmask(%s, sig=%d) failed: %s\n",
            block ? "SIG_BLOCK" : "SIG_UNBLOCK", sig, strerror(errno));
        exit(EXIT_FAILURE);
    }
}
/*--------------------------------------------------------------------*/
void handle_sigchld(void) {
    int   status;
    pid_t reaped_pid;

    /* Reap all children that have changed state */
    while ((reaped_pid = waitpid(-1, &status, WNOHANG)) > 0) {

        if (manager == NULL || manager->jobs == NULL || manager->n_jobs == 0) {
            continue;
        }

        /* Find which job this pid belongs to */
        for (int i = 0; i < manager->n_jobs; i++) {
            struct job *job = &manager->jobs[i];

            /* This will also update job->remaining_processes */
            if (remove_pid_from_job(job, pid)) {

                /* If all processes in this job are done */
                if (job->remaining_processes == 0) {
                    int jobid      = job->job_id;
                    pid_t pgid     = job->pgid;
                    job_state state = job->state;

                    /* If it was a background job, notify the user */
                    if (state == BACKGROUND) {
                        printf("Job [%d] with PGID %d finished\n",
                               jobid, (int)pgid);
                        fflush(stdout);
                    }

                    /* Remove job from job manager and free its pid list */
                    delete_job(jobid);
                }

                /* We’ve found the job for this pid, no need to scan further */
                break;
            }
        }
    }
}
/*--------------------------------------------------------------------*/
void handle_sigint(void) {
    if (manager == NULL || manager->jobs == NULL || manager->n_jobs == 0) {
        return;
    }

    /* Protect job table while we scan it */
    block_signal(SIGCHLD, TRUE);

    for (int i = 0; i < manager->n_jobs; i++) {
        struct job *job = &manager->jobs[i];

        if (job->state == FOREGROUND) {
            pid_t pgid = job->pgid;

            if (pgid > 0) {
                kill(-pgid, SIGINT);
            }
            break;
        }
    }

    block_signal(SIGCHLD, FALSE);
}
/*--------------------------------------------------------------------*/
void dup2_e(int oldfd, int newfd, const char *func, const int line) {
    int ret;

    ret = dup2(oldfd, newfd);
    if (ret < 0) {
        fprintf(stderr, 
            "Error dup2(%d, %d): %s(%s) at (%s:%d)\n", 
            oldfd, newfd, strerror(errno), errno_name(errno), func, line);
        exit(EXIT_FAILURE);
    }
}
/*--------------------------------------------------------------------*/
/* Do not modify this function. It is used to check the signals and 
 * handle them accordingly. It is called in the main loop of snush.c.
 */
void check_signals(void) {
    handle_sigchld();
    handle_sigint();
}
/*--------------------------------------------------------------------*/
void redout_handler(char *fname) { // *fname: filename to be used for redirection
    /*
    TODO: Implement redout_handler in execute.c
    */
    int fd;
    fd = open(fname, O_WRONLY | O_CREAT | O_TRUNC);
    if (fd < 0) {
        error_print(NULL, PERROR);
        exit(EXIT_FAILURE);
    } else {
        dup2_e(fd, STDOUT_FILENO, __func__, __LINE__);
        close(fd);
    }
    
}
/*--------------------------------------------------------------------*/
void redin_handler(char *fname) {
    int fd;

    fd = open(fname, O_RDONLY);
    if (fd < 0) {
        error_print(NULL, PERROR);
        exit(EXIT_FAILURE);
    } else {
        dup2_e(fd, STDIN_FILENO, __func__, __LINE__);
        close(fd);
    }
}
/*--------------------------------------------------------------------*/
void build_command_partial(DynArray_T oTokens, int start, 
                        int end, char *args[]) { //translates tokens (parsing result) into an argv array suitable for execvp() + performs IO redirection
    int i, redin = FALSE, redout = FALSE, cnt = 0;
    struct Token *t; //Temp pointer to the current token.

    /* Build command */
    for (i = start; i < end; i++) { //Loop over tokens from index start to end-1.
        t = dynarray_get(oTokens, i);

        if (t->token_type == TOKEN_WORD) { //If the token is a normal word 
            if (redin == TRUE) { //if that file(?) is supposed to be redin
                redin_handler(t->token_value);
                redin = FALSE;
            }
            else if (redout == TRUE) { //if that file(?) is supposed to be redout
                redout_handler(t->token_value);
                redout = FALSE;
            }
            else {
                args[cnt++] = t->token_value; //add token to args
            }
        }
        else if (t->token_type == TOKEN_REDIN)
            redin = TRUE;
        else if (t->token_type == TOKEN_REDOUT)
            redout = TRUE;
    }

    if (cnt >= MAX_ARGS_CNT) 
        fprintf(stderr, "[BUG] args overflow! cnt=%d\n", cnt);

    args[cnt] = NULL;

#ifdef DEBUG
    for (i = 0; i < cnt; i++) {
        if (args[i] == NULL)
            printf("CMD: NULL\n");
        else
            printf("CMD: %s\n", args[i]);
    }
    printf("END\n");
#endif
}
/*--------------------------------------------------------------------*/
void build_command(DynArray_T oTokens, char *args[]) { //convenience wrapper for the common case of “use ALL tokens”
    //Calls build_command_partial starting at index 0 and ending at dynarray_get_length(oTokens) → processing all tokens.
    build_command_partial(oTokens, 0, 
                        dynarray_get_length(oTokens), 
                        args);
}
/*--------------------------------------------------------------------*/
int execute_builtin_partial(DynArray_T toks, int start, int end,
                            enum BuiltinType btype, int in_child) { //Executes a built-in command (cd or exit) for a specific token range from start to end.
    // btype: which builtin it is (B_CD, B_EXIT).
    // in_child: TRUE if this builtin is inside a pipeline (e.g., cd | ls), FALSE if this builtin is in the main shell (no fork)

    int argc = end - start; //number of tokens within this slice.
    struct Token *t1;       //token pointer
    int ret;                // return code from chdir
    char *dir;              // directory string for cd

    switch (btype) {
    case B_EXIT:                //If exit appears inside a pipeline, the child must run the builtin
        if (in_child) return 0; //but in a pipeline, exit must not terminate the shell, only the child process.
        
        if (argc == 1) {        //If the command is exactly exit with no parameters:
            dynarray_map(toks, free_token, NULL); //Free token list, and token array
            dynarray_free(toks);
            exit(EXIT_SUCCESS); //Terminate the entire SNUSH shell 
        }
        else {
            error_print("exit does not take any parameters", FPRINTF);
            return -1;
        }

    case B_CD: { //means command is built-in, should be executed inside parent shell
        if (argc == 1) {
            dir = getenv("HOME");
            if (!dir) {
                error_print("cd: HOME variable not set", FPRINTF);
                return -1;
            }
        } 
        else if (argc == 2) {
            t1 = dynarray_get(toks, start + 1);
            if (t1 && t1->token_type == TOKEN_WORD) 
                dir = t1->token_value;
        } 
        else {
            error_print("cd: Too many parameters", FPRINTF);
            return -1;
        }

        ret = chdir(dir);
        if (ret < 0) {
            error_print(NULL, PERROR);
            return -1;
        }
        return 0;
    }

    default:
        error_print("Bug found in execute_builtin_partial", FPRINTF);
        return -1;
    }
}
/*--------------------------------------------------------------------*/
int execute_builtin(DynArray_T oTokens, enum BuiltinType btype) {
    return execute_builtin_partial(oTokens, 0, 
                                dynarray_get_length(oTokens), btype, FALSE);
}
/*--------------------------------------------------------------------*/
/* 
 * You need to finish implementing job related APIs. (find_job_by_jid(),
 * remove_pid_from_job(), delete_job()) in job.c to handle the job.
 * Feel free to modify the format of the job API according to your design.
 */
void wait_fg(int jobid) { //waits for a foreground job (which may consist of 1 or multiple processes in a pipeline)
    pid_t pid;  //result of waitpid
    int status; //exit status of child

     // Find the job structure by job ID
    struct job *job = find_job_by_jid(jobid);           //Look up the job in the job manager.
    if (!job) {                                         //Error if no such job exists.
        fprintf(stderr, "Job: %d not found\n", jobid);
        return;
    }

    while (1) {
        pid = waitpid(-job->pgid, &status, 0); //wait for any child in the process group pgid. this allows waiting for pipelines

        if (pid > 0) { //A child in that PGID has finished.
            if (!remove_pid_from_job(job, pid)) { //// Remove the finished process from the job's pid list
                fprintf(stderr, "Pid %d not found in the job: %d list\n", //If not found → something is wrong.
                    pid, job->job_id);
            }

            if (job->remaining_processes == 0) break; //If all processes in the pipeline finished → break out of wait loop
        }

        if (pid == 0) continue; //Should never happen because waitpid was called with blocking mode (0 flag)

        if (pid < 0) { //If waitpid fails:
            if (errno == EINTR) continue;   //EINTR: interrupted (e.g., by SIGINT) → retry
            if (errno == ECHILD) break;     //ECHILD: no more children → break loop
            error_print("Unknown error waitpid() in wait_fg()", PERROR);
        }
    }

    // Clean up job table entry from job manager. if all processes are done.
    if (job->remaining_processes == 0)
        delete_job(job->job_id);
}
/*--------------------------------------------------------------------*/
void print_job(int jobid, pid_t pgid) {
    fprintf(stdout, 
        "[%d] Process group: %d running in the background\n", jobid, pgid);
}
/*--------------------------------------------------------------------*/
int fork_exec(DynArray_T oTokens, int is_background) { // handles the execution of a single command, which may include I/O redirection
    //oTokens: sequence of tokens parsed from the user's command line input. The entire command line broken up into individual words and symbols
    /*
     * TODO: Implement fork_exec() in execute.c
     * To run a newly forked process in the foreground, call wait_fg() 
     * to wait for the process to finish.  
     * To run it in the background, call print_job() to print job id and
     * process group id.  
     * All terminated processes must be handled by sigchld_handler() in * snush.c. 
     */
     int new_jobid = -1;
     pid_t pid = fork();
     job_state state;

     if (pid < 0 ){ //if fork fails
        perror("fork failed");
        return -1;
     } else if (pid == 0) { //child process
        setpgid(0, 0); //set pgid to be same as child's pid

        char *args[MAX_ARGS_CNT];
        build_command(oTokens, args);

        if (args[0] == NULL) { //if build command produced no program
            _exit(EXIT_SUCCESS);
        }

        execvp(args[0], args);
        error_print(NULL, PERROR);
        exit(EXIT_FAILURE);

     } else if (pid > 0){ //parent process
        setpgid(pid, pid);

        pid_t pid_list[1];
        pid_list[0] = pid;

        state = is_background ? BACKGROUND : FOREGROUND;

        new_jobid = add_job(pid, pid_list, 1, state);
        if(new_jobid < 0){
            fprintf(stderr, "failed to add job");
            kill(pid, SIGKILL);
            return -1;
        }

        if(!is_background){ //foreground
            wait_fg(new_jobid);
        } else{ //background
            print_job(new_jobid, pid);
        }

     }

    return new_jobid;
}
/*--------------------------------------------------------------------*/
int iter_pipe_fork_exec(int n_pipe, DynArray_T oTokens, int is_background) {
    /*
     * TODO: Implement iter_pipe_fork_exec() in execute.c
     * To run a newly forked process in the foreground, call wait_fg() 
     * to wait for the process to finish.  
     * To run it in the background, call print_job() to print job id and
     * process group id.  
     * All terminated processes must be handled by sigchld_handler() in * snush.c. 
     */

    int jobid = 1;  
    return jobid;
}
/*--------------------------------------------------------------------*/
